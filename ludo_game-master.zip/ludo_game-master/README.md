# Ludo_Game

Offline ludo game developed in android studio
Ludo game developed in java and this is to illustrate canvas in android with threading for game development.
This is 2D game developed for a simple stat of game development in android studio !

<div class="container d-flex justify-content-center">

  <div class="float-child">
    <img src="https://github.com/sudhanshuGt/ludo_game/blob/master/app/src/main/res/drawable/ludostart.jpg" width="400" height="790">
  </div>
  
  <div class="float-child">
    <div class="blue">
      <img src="https://github.com/sudhanshuGt/ludo_game/blob/master/app/src/main/res/drawable/ludoactivity.jpg"  width="400" height="790">
    </div>
  </div>
  
</div>


